Driver Monitoring Model implemented using CNN + LSTM.
Model deployed on Flask
